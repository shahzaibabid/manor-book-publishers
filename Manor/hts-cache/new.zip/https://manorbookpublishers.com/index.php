<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manorbookpublishers | Home</title>
    
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-17879032170"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'AW-17879032170');
    </script>
    
    <link rel="stylesheet" href="assets/css/index.css">
    
    <link rel="icon" type="image/x-icon" href="./assets/images/favicon.ico">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" media="print" onload="this.media='all'">

    <link rel="stylesheet" href="https://unpkg.com/swiper@9/swiper-bundle.min.css" />
    
    

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/@dotlottie/player-component@2.7.12/dist/dotlottie-player.mjs" type="module" defer></script>
    
    <style type="text/tailwindcss">
        @layer base {
            html { -webkit-tap-highlight-color: transparent; }
        }
    </style>
    
    <!-- Meta Pixel Code -->
    <script>
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t,s)}(window, document,'script',
        'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '1530364625184114');
        fbq('track', 'PageView');
    </script>
   <noscript>
        <img height="1" width="1" style="display:none"
        src="https://www.facebook.com/tr?id=1530364625184114&ev=PageView&noscript=1"
        />
    </noscript>
    <!-- End Meta Pixel Code -->
</head>

<body>
    <header
        class="md:w-[80vw] w-screen mx-auto py-2 bg-transparent absolute top-0 flex justify-between items-center left-[50%] right-[50%] -translate-x-[50%] pt-6 md:px-0 px-4 !z-50">
        <a href="https://www.manorbookpublishers.com">
        <img loading="lazy" src="./assets/images/logo.png" alt="logo" class="w-40 object-contain">
        </a>
        <nav class="hidden md:flex items-center !text-white">
            <div>
                <a href="./index.php" class="ml-6 pb-1 border-b border-b-[var(--theme)] text-[var(--theme)]">Home</a>
            </div>
            <div>
                <a href="./about-us" class="ml-6">About Us</a>
            </div>
            <div class="relative !z-50 group">
                <a href="#" class="ml-6 flex items-center">
                    Services
                    <i class="fa fa-angle-down ml-2"></i>
                </a>
                <!-- Dropdown Menu -->
                <div
                    class="absolute hidden group-hover:flex flex-col bg-white text-black shadow-lg rounded-md top-full left-0 !z-[99] w-[335px]">
            
                    <a href="./professional-ghostwriting-services"
                        class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Ghostwriting</a>
                
                    <a href="./ebook-writing-services"
                        class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">EBook Writing</a
                >
                    <a href="./book-editing-services"
                        class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Book Editing
                </a>
                    <a href="./book-cover-design" class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Book
                        Cover Design</a>
                
                    <a href="./ebook-cover-design"
                        class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">EBook Cover Design</a>
                    <a href="https://manorbookpublishers.com/book-writing" class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Book
                        Writing</a>
                
                    <a href="./book-marketing" class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Book
                        Marketing</a>
                
                    <a href="https://manorbookpublishers.com/biography-writing"
                        class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Biography
                Writing</a>
                    <a href="./memoir-writing" class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Memoir
                        Writing</a>
                
                    <a href="./book-printing" class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Book
                        Printing</a>
                
                    <a href="./book-trailer-services"
                        class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Book Trailer</a>
                
                    <a href="./audiobook-publishing-services"
                        class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Audio Book</a>
                
                    <a href="./author-website-design"
                        class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Author Website</a>
                
                    <a href="./book-illustration-services"
                        class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Book Illustration</a>
                </div>
            </div>
            <!-- <div>
    
                <a href="./blogs" class="ml-6">Blog</a>
            </div> -->
            <div>
        
                <a href="./contact-us" class="ml-6">Contact Us</a>
            </div>
        </nav>
        <!--the change-->
        <div class="md:flex hidden gap-4 items-center">

    <!-- TFN #1 -->
    <div class="flex justify-center items-center h-11 w-11 rounded-full border !text-white rotate-90">
        <i class="fa fa-phone" aria-hidden="true"></i>
    </div>
    <div class="flex flex-col justify-between text-white">
        <div class="text-red-500 text-lg">Call Us</div>
        <a href="tel:+18337471898" class="text-sm">+1 (833) 747-1898</a>
    </div>

    <!-- TFN #2 -->
    <!--<div class="flex justify-center items-center h-11 w-11 rounded-full border !text-white rotate-90">-->
    <!--    <i class="fa fa-phone" aria-hidden="true"></i>-->
    <!--</div>-->
    <!--<div class="flex flex-col justify-between text-white">-->
    <!--    <div class="text-red-500 text-lg">Call Us</div>-->
    <!--    <a href="tel:+18337471898" class="text-sm">+1 (315) 594-4412</a>-->
    <!--</div>-->

</div>
        <!--the change end-->
        <div onclick="handleMobileMenu()"
            class="flex md:hidden h-11 border-2 w-16 gradientBg justify-center items-center">
            <i class="fa fa-bars text-white text-xl" aria-hidden="true"></i>
        </div>
    </header>
    <div id="mobileMenu"
        class="!h-0 !overflow-hidden !transition-all md:hidden !duration-700 w-[92%] left-[50%] right-[50%] -translate-x-[50%] absolute top-32 bg-[url(assets/images/home/menu-bg.jpg)] bg-cover bg-no-repeat bg-center rounded-lg text-black space-y-7">
        <div class="pt-8">
            <a href="./index.php" class="pl-6 pb-1 text-[var(--theme)]">Home</a>
        </div>
        <div>
    
            <a href="./about-us" class="pl-6">About Us</a>
        </div>
        <div id="dropCont" class="relative !z-50 group">
            <a href="#" class="pl-6 flex items-center">
                Services
                <i class="fa fa-angle-down ml-2"></i>
            </a>
            <!-- Dropdown Menu -->
            <div id="dropMob"
                class="absolute !hidden flex-col bg-black text-black shadow-lg rounded-md top-full left-0 !z-[99999999px
        ] w-[90vw]">
                <a href="./professional-ghostwriting-services"
                    class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Ghostwriting</a>
            
                <a href="./ebook-writing-services"
                    class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">EBook Writing</a>
            
                <a href="./book-editing-services" class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Book
                    Editing</a>
            
                <a href="./book-cover-design" class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Book
                    Cover Design</a>
            
                <a href="./ebook-cover-design" class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">EBook
                    Cover Design</a>
            
                <a href="https://manorbookpublishers.com/book-writing" class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Book
                    Writing</a>
            
                <a href="./book-marketing" class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Book
                    Marketing</a>
            
                <a href="https://manorbookpublishers.com/biography-writing" class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Biography
                    Writing</a>
            
                <a href="./memoir-writing" class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Memoir
                    Writing</a>
            
                <a href="./book-printing" class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Book
                    Printing</a>
            
                <a href="./book-trailer-services" class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Book
                    Trailer</a>
            
                <a href="./audiobook-publishing-services"
                    class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Audio Book</a>
            
                <a href="./author-website-design"
                    class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Author Website</a>
            
                <a href="./book-illustration-services"
                    class="gradient2 pl-3 hoverbg py-[6px] border-b text-white">Book Illustration</a>
            </div>
        </div>
        <div>
    
            <a href="./blogs" class="pl-6">Blog</a>
        </div>
        <div>
    
            <a href="./contact-us" class="pl-6">Contact Us</a>
        </div>
    <!--mobile menu updated code-->
<div class="md:hidden w-[95%] pl-4 mx-auto mt-4 flex items-center justify-start gap-4 flex-nowrap">

    <!-- TFN #1 -->
    <div class="flex items-center gap-2 flex-shrink-0">
        <!--<div class="flex justify-center items-center h-11 w-11 rounded-full border !text-black rotate-90 flex-shrink-0">-->
           <!--<i class="fa fa-phone" aria-hidden="true"></i>-->
        <!--</div>-->
        <div class="flex flex-col justify-between text-black">
            <div class="text-red-500 text-lg leading-tight">Call Us</div>
            <a href="tel:+18337471898" class="text-sm">+1 (833) 747-1898</a>
        </div>
    </div>

    <!-- TFN #2 -->
    <div class="flex items-center gap-2 flex-shrink-0">
        <!--<div class="flex justify-center items-center h-11 w-11 rounded-full border !text-black rotate-90 flex-shrink-0">-->
        <!--    <i class="fa fa-phone" aria-hidden="true"></i>-->
        <!--</div>-->
        <!--<div class="flex flex-col justify-between text-black">-->
        <!--    <div class="text-red-500 text-lg leading-tight">Call Us</div>-->
        <!--    <a href="tel:+18337471898" class="text-sm">+1 (315) 594-4412</a>-->
        <!--</div>-->
    </div>

</div>

        <!--mobile menu updated code end-->
    </div>

    <main
        class="bg-[url(assets/images/home/banner-img.jpg)] !h-fit md:!max-h-[250dvh] bg-center bg-no-repeat bg-cover md:pt-[173px] pt-36 md:pb-[500px] min-h-[180vh]">
        <section class="md:w-[80%] w-[93%] mx-auto grid md:grid-cols-2 md:gap-0 gap-12 items-center text-white">
            <div>
                <div class="flex items-center gap-1">
                    <img loading="lazy" src="assets/images/home/pen.png" alt="Pen">
                    <h5 class="text-[var(--theme)]">Want to Be an Author?</h5>
                </div>
                <h1 class="md:text-[40px] text-3xl leading-[1.2] mt-1 font-medium">Unlock the Delight of <span
                        class="text-[var(--theme)]">Bringing Your Book to Life: Allow Our Book Publishing</span>
                    Services to Lead You Toward Success</h1>
                <p class="mt-2 text-sm">
                    We offer you the chance to make your mark in the book world by publishing your manuscripts into an
                    actual book. Join our premium online book publishing services today!
                </p>
                <div class="flex md:gap-20 gap-5 flex-wrap items-center mt-5">
                    
                    <button onclick="toggleModal()"
                        class="gradientBg text-white h-[50px] w-[170px] justify-center rounded-xl text-sm flex gap-1 items-center">
                        Get Started Today
                        <i class="fa fa-angle-right"></i>
                    </button>
                    
                    <div class="flex gap-2 items-center">
                        <div
                            class="flex justify-center items-center h-11 w-11 rounded-full border !text-white rotate-90">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                        </div>
                        <div class="flex flex-col justify-between text-white">
                            <div class="text-lg">Call Us</div>
                            <a href="tel:+18337471898" class="text-sm">+1 (833) 747-1898</a>
                        </div>
                    </div>
                </div>
            </div>
          
          <form
    action="sendEmail.php"
    method="POST"
    class="md:w-[80%] w-full mx-auto md:ml-auto md:mr-0 px-6 pt-6 pb-[50px] bg-[#041318] gradientBorder rounded-xl relative z-0">
    <h1 class="text-2xl font-light md:w-full w-[82%]">
        Sign Up Now to <span class="text-[var(--theme)]">Get 50%</span> Discount
    </h1>
    <div class="mt-5 space-y-4">
        <div class="grid grid-cols-2 gap-3">
            <input type="text" name="fullName" placeholder="Full Name"
                class="py-[9px] px-4 bg-white text-black rounded-[7px]" required />
            <input type="email" name="email" placeholder="Email Address"
                class="py-[9px] px-4 bg-white text-black rounded-[7px]" required />
        </div>
        <div class="grid grid-cols-2 gap-3">
            <select name="service" class="py-[9px] px-4 bg-white text-black rounded-[7px]" required>
                <option value="" disabled selected>Select your Service</option>
                <option value="Ghostwriting Services">Ghostwriting Services</option>
                <option value="Book Editing Services">Book Editing Services</option>
                <option value="Book Cover Design Services">Book Cover Design Services</option>
                <option value="Ebook Cover Design Services">Ebook Cover Design Services</option>
                <option value="Book Publishing Services">Book Publishing Services</option>
                <option value="Book Marketing Services">Book Marketing Services</option>
                <option value="Ebook Writing Services">Ebook Writing Services</option>
                <option value="Biography Writing Services">Biography Writing Services</option>
                <option value="Memoir Writing Services">Memoir Writing Services</option>
                <option value="Book Printing Services">Book Printing Services</option>
                <option value="Video Book Services">Video Book Services</option>
                <option value="Audio Book Services">Audio Book Services</option>
                <option value="Author Website Services">Author Website Services</option>
                <option value="Book Illustration Services">Book Illustration Services</option>
            </select>
            <input type="number" id="phoneInput" name="phone" placeholder="Phone Number"
                class="py-[9px] px-4 bg-white text-black rounded-[7px]" required />
        </div>
        <textarea name="brief" placeholder="Brief.." class="w-full py-[9px] px-5 bg-white text-black rounded-[7px]"
            rows="3" required></textarea>
        <button type="submit" class="text-white gradientBg py-3 w-full rounded-lg">Sign Up</button>
    </div>
    <img loading="lazy" src="/assets/images/home/formAbsolute.jpg" alt="Deep Water"
        class="absolute md:-right-10 right-1 md:-top-8 -top-10 rotate-[22deg] h-28 object-contain" />
</form>

          
        </section>
        <div class="md:mt-4 mt-11 md:w-[80%] w-[90%] mx-auto">
            <img loading="lazy" src="/assets/images/home/banner-inner-img.jpg" alt="">
        </div>
        <div class="marquee">
            <div class="track">
                <div class="content flex items-center gap-28">
                    <img loading="lazy" src="/assets/images/home/marquee/0.png" class="h-16 object-cover brightness-0 invert   ">
                    <img loading="lazy" src="/assets/images/home/marquee/1.png" class="h-10 object-cover brightness-0 invert   ">
                    <img loading="lazy" src="/assets/images/home/marquee/2.png" class="h-10 object-cover brightness-0 invert   ">
                    <img loading="lazy" src="/assets/images/home/marquee/3.png" class="h-10 object-cover brightness-0 invert   ">
                    <img loading="lazy" src="/assets/images/home/marquee/4.png" class="h-4 object-cover brightness-0 invert    ">
                    <img loading="lazy" src="/assets/images/home/marquee/5.png"
                        class="w-[224px] h-20 object-cover brightness-0 invert ">
                    <img loading="lazy" src="/assets/images/home/marquee/0.png" class="h-16 object-cover brightness-0 invert   ">
                    <img loading="lazy" src="/assets/images/home/marquee/1.png" class="h-12 object-cover brightness-0 invert   ">
                    <img loading="lazy" src="/assets/images/home/marquee/2.png" class="h-12 object-cover brightness-0 invert   ">
                    <img loading="lazy" src="/assets/images/home/marquee/3.png" class="h-12 object-cover brightness-0 invert   ">
                    <img loading="lazy" src="/assets/images/home/marquee/4.png" class="h-5 object-cover brightness-0 invert    ">
                    <img loading="lazy" src="/assets/images/home/marquee/5.png"
                        class="w-[224px] h-20 object-cover brightness-0 invert ">
                </div>
            </div>
        </div>
        <div class="md:mt-5 mt-12 md:w-[50vw] mx-auto pt-[18%]">
            <h1 class="md:text-[40px] text-3xl text-center font-[500] leading-tight ">
                Dream Big On Becoming The <span class="text-[var(--theme2)]">Next Bestseller With Expert Online</span>
                Book Publishing Services
            </h1>
            <p class="text-center mt-2 text-[14px]">Publish your book through us and we promise to make it worthwhile.
            </p>
        </div>
        <section id="about" class="mt-8 md:mt-0 grid md:grid-cols-2 items-center md:gap-5 md:w-[80%] w-[90%] mx-auto">
            <div class="">
                <div class="flex items-end gap-2">
                    <img loading="lazy" src="/assets/images/home/pen-about.png" alt="pen">
                    <h5 class="text-[var(--theme2)]">Book Publishing Services</h5>
                </div>
                <h3 class="text-[30px] font-[600] leading-[42px] mt-4 ">Book publishing <span
                        class="capitalize text-[var(--theme2)]">services at Its Very</span> Best Right
                    Here.</h3>
                <p class="mt-3 text-sm">
                    We enable authors to independently publish their writings digitally with our amazon book publishing
                    services, including e-books, audiobooks, and print-on-demand books. Our skilled team offers a
                    user-friendly and cost-effective solution for authors to have their creations published and made
                    available to a wide readership through well-known platforms like Google and Amazon, among others.
                </p>
                <div class="flex md:gap-20 gap-2 items-center mt-5">
                    
                    <button onclick="toggleModal()"
                        class="gradientBg text-white h-[50px] w-[170px] justify-center rounded-xl text-sm flex gap-1 items-center">
                        Get Started Today
                        <i class="fa fa-angle-right"></i>
                    </button>
                    
                    <div class="flex gap-2 items-center">
                        <div
                            class="flex justify-center items-center h-11 w-11 rounded-full border border-black !text-black rotate-90">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                        </div>
                        <div class="flex flex-col justify-between text-black">
                            <div class="text-lg">Call Us</div>
                            <a href="tel:+18337471898" class="text-sm">+1 (833) 747-1898</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="">
                <dotlottie-player src="https://lottie.host/1b94d635-f280-4994-a66a-da1c90a9b321/g7l2MJ3XjV.json"
                    background="transparent" speed="1" loop="" autoplay=""
                    class="md:w-[600px] h-auto w-[90%]"></dotlottie-player>
            </div>
        </section>
    </main>

    <section class="md:mt-32 mt-14 grid md:grid-cols-2 items-center gap-4 w-[88.9vw] md:mr-auto md:ml-0 mx-auto">
        <img loading="lazy" src="/assets/images/home/about.png" alt="About Books" class="w-[935px] md:order-1 order-2">
        <div class="md:order-2 order-1">
            <div class="flex items-end gap-2">
                <img loading="lazy" src="/assets/images/home/pen-about.png" alt="pen">
                <h5 class="text-[var(--theme2)]">About Company</h5>
            </div>
            <h3 class="text-[30px] font-[600] leading-[42px] mt-4 ">Looking for <span
                    class="capitalize text-[var(--theme2)]">Amazon Book Publishing Services </span> Look No More!</h3>
            <p class="mt-2 text-[14px] font-[400] !font-[Poppins] text-[#000] ">
                At Manorbookpublishers, we pride ourselves on delivering professional online book publishing services
                guided by a meticulous process, all thanks to our team of expert book publishers.
            </p>
            <ul class="mt-5 space-y-3">
                <li class="flex items-start gap-2">
                    <img loading="lazy" src="assets/images/home/check.svg" alt="check" class="h-4 mt-1">
                    <div class="text-sm"><span class="font-bold text-base">Consultation:</span> We begin by grasping
                        your vision, whether you're an aspiring author or a business professional. Our book publishers
                        explore your goals, audience, and style.</div>
                </li>
                <li class="flex items-start gap-2">
                    <img loading="lazy" src="assets/images/home/check.svg" alt="check" class="h-4 mt-1">
                    <div class="text-sm"><span class="font-bold text-base">Planning:</span> We create a comprehensive
                        plan, including the book's publishing schedule when you receive our amazon book publishing
                        services.</div>
                </li>
                <li class="flex items-start gap-2">
                    <img loading="lazy" src="assets/images/home/check.svg" alt="check" class="h-4 mt-1">
                    <div class="text-sm"><span class="font-bold text-base">Publishing:</span> With your input and our
                        expertise, we begin the professional book publishing process.</div>
                </li>
                <li class="flex items-start gap-2">
                    <img loading="lazy" src="assets/images/home/check.svg" alt="check" class="h-4 mt-1">
                    <div class="text-sm"><span class="font-bold text-base">Post-Publishing:</span>Our professional book
                        publishing company keep tabs on your book, post publishing to meet the highest publishing
                        standards.</div>
                </li>
                <li class="flex items-start gap-2">
                    <img loading="lazy" src="assets/images/home/check.svg" alt="check" class="h-4 mt-1">
                    <div class="text-sm"><span class="font-bold text-base">Quality Assurance:</span> We begin by
                        grasping your vision, whether you're an aspiring author or a business professional. Our book
                        publishers explore your goals, audience, and style.</div>
                </li>
                <li class="flex items-start gap-2">
                    <img loading="lazy" src="assets/images/home/check.svg" alt="check" class="h-4 mt-1">
                    <div class="text-sm"><span class="font-bold text-base">Consultation:</span> Once your manuscript is
                        published, the quality assurance department of our book publishing company will make sure all
                        the client's requirements are met</div>
                </li>
            </ul>

            <div class="flex gap-10 items-center mt-5">
              
                <button onclick="toggleModal()"
                    class="gradientBg text-white h-[50px] w-[170px] justify-center rounded-xl text-sm flex gap-1 items-center">
                    Get Started Today
                    <i class="fa fa-angle-right"></i>
                </button>
                
                <div class="flex gap-2 items-center">
                    <div
                        class="flex justify-center items-center h-11 w-11 rounded-full border border-black !text-black rotate-90">
                        <i class="fa fa-phone" aria-hidden="true"></i>
                    </div>
                    <div class="flex flex-col justify-between text-black">
                        <div class="text-lg">Call Us</div>
                        <a href="tel:+18337471898" class="text-sm">+1 (833) 747-1898</a>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <section class="mt-28 md:w-[82%] w-[95%] mx-auto">
        <h1 class="w-fit text-center md:text-[40px] text-[35px] capitalize mx-auto font-[600]">
            Services Rendered by
            <span class="text-[var(--theme2)] leading-[50px]">Manorbookpublishers</span>
        </h1>
        <div class="swiper mySwiper">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="servicesBox">
                        <div class="iconBox">
                            <img loading="lazy" src="/assets/images/home/services/1.png" alt="service 1">
                        </div>
                        <div class="relative z-20">
                            <h1 class="service-num">01</h1>
                            <h1 class="text-[16px] text-center font-[500] py-3 ">Ebook Writing</h1>
                            <div class="service-divider">
                                <div class="divider"></div>
                            </div>
                            <p class="service-desc">
                                At Manorbookpublishers, we render exceptional writing services for every genre. Our
                                expert team transforms your vision into a riveting eBook that captivates readers.
                            </p>
                            <div class="service-btn mt-4">
                                <a href="ebook-writing-services" tabindex="-1">Learn More<i class="fa fa-plus"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="servicesBox">
                        <div class="iconBox">
                            <img loading="lazy" src="/assets/images/home/services/2.png" alt="service 2">
                        </div>
                        <div class="relative z-20">
                            <h1 class="service-num">02</h1>
                            <h1 class="text-[16px] text-center font-[500] py-3 ">Ebook Editing</h1>
                            <div class="service-divider">
                                <div class="divider"></div>
                            </div>
                            <p class="service-desc">
                                Our seasoned editors refine your manuscript with meticulous attention to detail. From
                                narrative flow to grammatical finesse, we ensure your eBook is polished to perfection.
                            </p>
                            <div class="service-btn mt-4">
                                <a href="https://manorbookpublishers.com/book-editing-services" tabindex="-1">Learn More<i class="fa fa-plus"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--<div class="swiper-slide">-->
                <!--    <div class="servicesBox">-->
                <!--        <div class="iconBox">-->
                <!--            <img loading="lazy" src="/assets/images/home/services/3.png" alt="service 3">-->
                <!--        </div>-->
                <!--        <div class="relative z-20">-->
                <!--            <h1 class="service-num">03</h1>-->
                <!--            <h1 class="text-[16px] text-center font-[500] py-3 ">Ebook Proofreading</h1>-->
                <!--            <div class="service-divider">-->
                <!--                <div class="divider"></div>-->
                <!--            </div>-->
                <!--            <p class="service-desc">-->
                <!--                Our proofreading experts meticulously scan your eBook for spelling errors, typos, and-->
                <!--                punctuation slips, ensuring a flawless, professional final product.-->
                <!--            </p>-->
                <!--            <div class="service-btn mt-4">-->
                <!--                <a href="./book-proofreading-services" tabindex="-1">Learn More<i class="fa fa-plus"-->
                <!--                        aria-hidden="true"></i></a>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="swiper-slide">-->
                <!--    <div class="servicesBox">-->
                <!--        <div class="iconBox">-->
                <!--            <img loading="lazy" src="/assets/images/home/services/4.png" alt="service 4">-->
                <!--        </div>-->
                <!--        <div class="relative z-20">-->
                <!--            <h1 class="service-num">04</h1>-->
                <!--            <h1 class="text-[16px] text-center font-[500] py-3 ">Ebook Formatting</h1>-->
                <!--            <div class="service-divider">-->
                <!--                <div class="divider"></div>-->
                <!--            </div>-->
                <!--            <p class="service-desc">-->
                <!--                We ensure your eBook looks impeccable across all devices. Our formatting services-->
                <!--                optimize layout, fonts, and images for a seamless reading experience.-->
                <!--            </p>-->
                <!--            <div class="service-btn mt-4">-->
                <!--                <a href="./ebook-formatting-services" tabindex="-1">Learn More<i class="fa fa-plus"-->
                <!--                        aria-hidden="true"></i></a>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <div class="swiper-slide">
                    <div class="servicesBox">
                        <div class="iconBox">
                            <img loading="lazy" src="/assets/images/home/services/5.png" alt="service 5">
                        </div>
                        <div class="relative z-20">
                            <h1 class="service-num">05</h1>
                            <h1 class="text-[16px] text-center font-[500] py-3 ">EBook Marketing</h1>
                            <div class="service-divider">
                                <div class="divider"></div>
                            </div>
                            <p class="service-desc">
                                Let us shine the spotlight on your life story. Our book marketing services connect
                                your work with the right audience, maximizing reach and impact.
                            </p>
                            <div class="service-btn mt-4">
                                <a href="./book-marketing" tabindex="-1">Learn More<i class="fa fa-plus"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="servicesBox">
                        <div class="iconBox">
                            <img loading="lazy" src="/assets/images/home/services/6.png" alt="service 6">
                        </div>
                        <div class="relative z-20">
                            <h1 class="service-num">06</h1>
                            <h1 class="text-[16px] text-center font-[500] py-3 ">Biography Writing</h1>
                            <div class="service-divider">
                                <div class="divider"></div>
                            </div>
                            <p class="service-desc">
                                Our talented writers bring real lives to the page with honesty and nuance. We craft
                                biographies that honor experiences, resonating deeply with readers.
                            </p>
                            <div class="service-btn mt-4">
                                <a href="https://manorbookpublishers.com/biography-writing" tabindex="-1">Learn More<i class="fa fa-plus"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="servicesBox">
                        <div class="iconBox">
                            <img loading="lazy" src="/assets/images/home/services/7.png" alt="service 7">
                        </div>
                        <div class="relative z-20">
                            <h1 class="service-num">07</h1>
                            <h1 class="text-[16px] text-center font-[500] py-3 ">Ghostwriting Services</h1>
                            <div class="service-divider">
                                <div class="divider"></div>
                            </div>
                            <p class="service-desc">
                                Partner with our discreet ghostwriters to give voice to your ideas. We craft compelling
                                manuscripts while you retain full authorship and creative control.
                            </p>
                            <div class="service-btn mt-4">
                                <a href="./professional-ghostwriting-services" tabindex="-1">Learn More<i class="fa fa-plus"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="servicesBox">
                        <div class="iconBox">
                            <img loading="lazy" src="/assets/images/home/services/8.png" alt="service 8">
                        </div>
                        <div class="relative z-20">
                            <h1 class="service-num">08</h1>
                            <h1 class="text-[16px] text-center font-[500] py-3 ">Ebook Cover Design</h1>
                            <div class="service-divider">
                                <div class="divider"></div>
                            </div>
                            <p class="service-desc">
                                Our designers create visually striking covers that capture your eBook’s essence. Make a
                                memorable first impression that turns browsing into buying.
                            </p>
                            <div class="service-btn mt-4">
                                <a href="ebook-cover-design" tabindex="-1">Learn More<i class="fa fa-plus"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="servicesBox">
                        <div class="iconBox">
                            <img loading="lazy" src="/assets/images/home/services/9.png" alt="service 9">
                        </div>
                        <div class="relative z-20">
                            <h1 class="service-num">09</h1>
                            <h1 class="text-[16px] text-center font-[500] py-3 ">Memoir</h1>
                            <div class="service-divider">
                                <div class="divider"></div>
                            </div>
                            <p class="service-desc">
                                We help transform your personal stories into a captivating memoir. Share your unique
                                journey in a way that resonates and inspires your readers.
                            </p>
                            <div class="service-btn mt-4">
                                <a href="./memoir-writing" tabindex="-1">Learn More<i class="fa fa-plus"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="swiper-pagination"></div>
        </div>
    </section>

    <section
        class="md:w-[83%] w-full mx-auto mt-20 py-7 bg-[url(assets/images/home/counter-bg.png)] bg-no-repeat bg-center bg-cover font-family text-white rounded-lg md:px-0 px-[3vw]">
        <h1 class="text-[34px] font-[600] mt-3 pt-5 text-center">Figures that Speak Volume</h1>
        <p class="text-center text-[14px] md:max-w-[70%] mx-auto mt-2">Our achievements are a testament to our
            dedication,
            and we consistently work towards enhancing our performance to surpass the expected standards.</p>
        <div class="grid md:grid-cols-4 grid-cols-2 md:gap-0 gap-16 mt-8">
            <div>
                <div class="w-fit mx-auto">
                    <h4 class="font-[600] text-[var(--theme)] text-[32px] text-center">672</h4>
                    <p class="text-[18px] font-[400] capitalize text-center">Projects Completed</p>
                </div>
            </div>
            <div>
                <div class="w-fit mx-auto">
                    <h4 class="font-[600] text-[var(--theme)] text-[32px] text-center">10</h4>
                    <p class="text-[18px] font-[400] capitalize text-center">Years of Experience</p>
                </div>
            </div>
            <div>
                <div class="w-fit mx-auto">
                    <h4 class="font-[600] text-[var(--theme)] text-[32px] text-center">100</h4>
                    <p class="text-[18px] font-[400] capitalize text-center">Staff Members</p>
                </div>
            </div>
            <div>
                <div class="w-fit mx-auto">
                    <h4 class="font-[600] text-[var(--theme)] text-[32px] text-center">97</h4>
                    <p class="text-[18px] font-[400] capitalize text-center">Satisfaction Rate</p>
                </div>
            </div>
        </div>
    </section>

    <section class="md:w-[79.4%] w-[90%] mx-auto mt-24">
        <!-- Title -->
        <h1 class="w-fit text-center md:text-[40px] text-3xl capitalize mx-auto font-[600]">
            Take A Look at <span class="text-[var(--theme2)]">Our Portfolio</span>
        </h1>
        <p class="text-[16px] font-[400] text-center mt-2">At Manorbookpublishers, we find satisfaction in our extensive
            portfolio, demonstrating our proficiency across a wide array of industries and niches.</p>

        <!-- Tabs -->
        <div class="mt-6 flex justify-center flex-wrap gap-4">
            <button class="tab-button active px-6 py-3 text-white bg-[var(--theme)] rounded-l"
                data-tab="fiction">Fiction</button>
            <button class="tab-button px-6 py-3 text-gray-700 bg-gray-300" data-tab="nonfiction">Non Fiction</button>
            <button class="tab-button px-6 py-3 text-gray-700 bg-gray-300 rounded-r"
                data-tab="biography">Biography</button>
            <button class="tab-button px-6 py-3 text-gray-700 bg-gray-300 rounded-r"
                data-tab="children">Children</button>
            <button class="tab-button px-6 py-3 text-gray-700 bg-gray-300 rounded-r"
                data-tab="Informative">Informative</button>
        </div>

        <!-- Tab Content -->
        <div class="tab-content mt-6">
            <!-- Fiction Tab -->
            <div id="fiction" class="tab-panel block">
                <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <img loading="lazy" src="./assets/images/bookCover/1.webp" alt="Book 1" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/2.webp" alt="Book 2" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/3.webp" alt="Book 3" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/4.webp" alt="Book 4" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/5.webp" alt="Book 5" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/6.webp" alt="Book 1" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/7.webp" alt="Book 2" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/8.webp" alt="Book 3" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/9.webp" alt="Book 4" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/10.webp" alt="Book 5" class="rounded shadow-md">
                </div>
            </div>

            <!-- Non Fiction Tab -->
            <div id="nonfiction" class="tab-panel hidden">
                <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <img loading="lazy" src="./assets/images/bookCover/11.webp" alt="Book 6" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/12.webp" alt="Book 7" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/13.webp" alt="Book 8" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/14.webp" alt="Book 9" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/15.webp" alt="Book 10" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/16.webp" alt="Book 6" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/17.webp" alt="Book 6" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/18.webp" alt="Book 7" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/19.webp" alt="Book 8" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/20.webp" alt="Book 9" class="rounded shadow-md">
                </div>
            </div>

            <!-- Biography Tab -->
            <div id="biography" class="tab-panel hidden">
                <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <img loading="lazy" src="./assets/images/bookCover/21.webp" alt="Book 6" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/22.webp" alt="Book 7" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/23.webp" alt="Book 8" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/24.webp" alt="Book 9" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/25.webp" alt="Book 10" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/26.webp" alt="Book 6" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/27.webp" alt="Book 6" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/28.webp" alt="Book 7" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/29.webp" alt="Book 8" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/30.webp" alt="Book 9" class="rounded shadow-md">
                </div>
            </div>

            <!-- Children Tab -->
            <div id="children" class="tab-panel hidden">
                <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <img loading="lazy" src="./assets/images/bookCover/31.webp" alt="Book 6" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/32.webp" alt="Book 7" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/33.webp" alt="Book 8" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/34.webp" alt="Book 9" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/35.webp" alt="Book 10" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/36.webp" alt="Book 6" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/37.webp" alt="Book 6" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/38.webp" alt="Book 7" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/39.webp" alt="Book 8" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/40.webp" alt="Book 9" class="rounded shadow-md">
                </div>
            </div>

            <!-- Informative Tab -->
            <div id="Informative" class="tab-panel hidden">
                <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <img loading="lazy" src="./assets/images/bookCover/41.webp" alt="Book 6" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/42.webp" alt="Book 7" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/43.webp" alt="Book 8" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/44.webp" alt="Book 9" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/45.webp" alt="Book 10" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/46.webp" alt="Book 6" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/47.webp" alt="Book 6" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/48.webp" alt="Book 7" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/49.webp" alt="Book 8" class="rounded shadow-md">
                    <img loading="lazy" src="./assets/images/bookCover/50.webp" alt="Book 9" class="rounded shadow-md">
                </div>
            </div>
        </div>
    </section>

    <section
        class="mt-16 bg-[url(assets/images/home/amazon-sec-bg.png)] bg-center bg-cover bg-no-repeat min-h-screen flex items-center">
        <div class="w-full md:px-[3vw] px-5 mx-auto grid items-center grid-cols-1 md:grid-cols-10 gap-8 md:gap-5">
            <!-- Left Column -->
            <div class="md:col-span-4">
                <h1 class="text-3xl md:text-4xl capitalize font-semibold">
                    Our Published <span class="text-[var(--theme2)]">Work</span>
                </h1>
                <p class="text-sm md:text-base font-normal mt-2">
                  We believe that our work speaks for itself. Discover the Advantages of Selecting the Best Book Publishing Company for Your Dream Book. From riveting storytelling to inspiring stories, our most recent projects demonstrate the craftsmanship and passion that define our publishing journey.
                </p>
                
                <button onclick="toggleModal()"
                    class="gradientBg text-white h-12 w-full md:w-44 justify-center rounded-xl text-sm flex gap-1 items-center mt-5">
                    Get Started Today
                    <i class="fa fa-angle-right"></i>
                </button>
                
                <!--<div class="flex flex-col mt-5">-->
                <!--    <div class="text-red-500 text-lg">Call Us</div>-->
                <!--    <a href="tel:+18337471898" class="text-sm">+1 (833) 747-1898</a>-->
                <!--</div>-->
            </div>

            <!-- Right Column (Swiper Carousel) -->
            <div class="md:col-span-6">
                <div class="swiper mySwiper2 mt-11">
                    <div class="swiper-wrapper">
                        <!-- Swiper Slides -->
                        <!-- Repeat this block for each slide -->
                        <div class="swiper-slide relative">
                            <div class="w-full md:w-11/12 bg-white bg-opacity-60 py-6 px-5 shadow-lg rounded-lg">
                                <div class="flex flex-col md:flex-row gap-4 items-center">
                                    <img loading="lazy" class="w-16 h-16 md:w-20 md:h-20 object-cover rounded-full"
                                        src="/assets/images/home/client-placeholder.png" alt="Profile Picture">
                                    <div class="text-center md:text-left">
                                        <h3 class="text-lg md:text-xl font-medium">Brent Kunzler</h3>
                                        <p class="text-sm md:text-base font-normal">Assault On Ascension</p>
                                    </div>
                                </div>
                                <p class="text-sm md:text-base font-normal mt-4 md:mt-6">
                                   "Pull it out!" Gang demanded, screaming. They had completely forgotten about the operation for a second. The radio was calling. "Fuck that! Pull this out of my eye," Gang yelled. Muvang turned...
                                </p>
                                <div class="mt-6">
                                    <h5 class="flex items-center gap-2 text-sm md:text-base font-medium">
                                        Published on <img loading="lazy" src="assets/images/Amazon-logo.png" alt="Amazon Logo"
                                            class="w-20">
                                    </h5>
                                </div>
                                <a href="https://www.amazon.com/Assault-Ascension-Brent-Kunzler/dp/B0CJXLGVXV/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1696269045&sr=8-1" class="text-blue-600 text-sm md:text-base mt-2 inline-block">Visit Now</a>
                            </div>
                            <img loading="lazy" src="/assets/images/authorBbook/1.webp" alt="Author Books"
                                class="absolute -right-3 top-1/2 transform -translate-y-1/2 w-24 md:w-32">
                        </div>
                        <div class="swiper-slide relative">
                            <div class="w-full md:w-11/12 bg-white bg-opacity-60 py-6 px-5 shadow-lg rounded-lg">
                                <div class="flex flex-col md:flex-row gap-4 items-center">
                                    <img loading="lazy" class="w-16 h-16 md:w-20 md:h-20 object-cover rounded-full"
                                        src="/assets/images/home/client-placeholder.png" alt="Profile Picture">
                                    <div class="text-center md:text-left">
                                        <h3 class="text-lg md:text-xl font-medium">Don Anderson</h3>
                                        <p class="text-sm md:text-base font-normal">THE DAD RANTS</p>
                                    </div>
                                </div>
                                <p class="text-sm md:text-base font-normal mt-4 md:mt-6">
                                    My motivation for writing the "Dad Rants" was to convey to my kids in writing their dad's philosophy for living, and for decision making. They would then have a record of their dad's thoughts for posterity.
                                </p>
                                <div class="mt-6">
                                    <h5 class="flex items-center gap-2 text-sm md:text-base font-medium">
                                        Published on <img loading="lazy" src="assets/images/Amazon-logo.png" alt="Amazon Logo"
                                            class="w-20">
                                    </h5>
                                </div>
                                <a href="https://www.amazon.com/DAD-RANTS-Don-Anderson/dp/1961407043/ref=sr_1_4?crid=2BA2TBDI05NMB&keywords=Don+Anderson&qid=1696268823&sprefix=%2Caps%2C615&sr=8-4" class="text-blue-600 text-sm md:text-base mt-2 inline-block">Visit Now</a>
                            </div>
                            <img loading="lazy" src="/assets/images/authorBbook/2.webp" alt="Author Books"
                                class="absolute -right-3 top-1/2 transform -translate-y-1/2 w-24 md:w-32">
                        </div>
                        <div class="swiper-slide relative">
                            <div class="w-full md:w-11/12 bg-white bg-opacity-60 py-6 px-5 shadow-lg rounded-lg">
                                <div class="flex flex-col md:flex-row gap-4 items-center">
                                    <img loading="lazy" class="w-16 h-16 md:w-20 md:h-20 object-cover rounded-full"
                                        src="/assets/images/home/client-placeholder.png" alt="Profile Picture">
                                    <div class="text-center md:text-left">
                                        <h3 class="text-lg md:text-xl font-medium">Adam Pant</h3>
                                        <p class="text-sm md:text-base font-normal">The Mustangs' Headless</p>
                                    </div>
                                </div>
                                <p class="text-sm md:text-base font-normal mt-4 md:mt-6">
                                   Murders and mysteries in a small town unsolved because of money and power-child abuse, child molestation, assaults pre-mediated and paid for crimes
                                </p>
                                <div class="mt-6">
                                    <h5 class="flex items-center gap-2 text-sm md:text-base font-medium">
                                        Published on <img loading="lazy" src="assets/images/Amazon-logo.png" alt="Amazon Logo"
                                            class="w-20">
                                    </h5>
                                </div>
                                <a href="https://www.amazon.com/dp/B0CH3V2LFT?ref_=cm_sw_r_cp_ud_dp_0ZGF9WDC4N8Q9M8843WQ" class="text-blue-600 text-sm md:text-base mt-2 inline-block">Visit Now</a>
                            </div>
                            <img loading="lazy" src="/assets/images/authorBbook/3.webp" alt="Author Books"
                                class="absolute -right-3 top-1/2 transform -translate-y-1/2 w-24 md:w-32">
                        </div>
                        <div class="swiper-slide relative">
                            <div class="w-full md:w-11/12 bg-white bg-opacity-60 py-6 px-5 shadow-lg rounded-lg">
                                <div class="flex flex-col md:flex-row gap-4 items-center">
                                    <img loading="lazy" class="w-16 h-16 md:w-20 md:h-20 object-cover rounded-full"
                                        src="/assets/images/home/client-placeholder.png" alt="Profile Picture">
                                    <div class="text-center md:text-left">
                                        <h3 class="text-lg md:text-xl font-medium">Keshawn Hardeman</h3>
                                        <p class="text-sm md:text-base font-normal">Miracles I’ve Witnessed</p>
                                    </div>
                                </div>
                                <p class="text-sm md:text-base font-normal mt-4 md:mt-6">
                                    I'm a Ex gang banger,drug dealer gun shot brain trauma survivor who made a deal with the devil & God payed my debt in God I trust.
                                </p>
                                <div class="mt-6">
                                    <h5 class="flex items-center gap-2 text-sm md:text-base font-medium">
                                        Published on <img loading="lazy" src="assets/images/Amazon-logo.png" alt="Amazon Logo"
                                            class="w-20">
                                    </h5>
                                </div>
                                <a href="https://www.amazon.com/dp/B0CH2FQ5VV?ref_=cm_sw_r_cp_ud_dp_VMSTNGA2FZ1MGXHYYK55" class="text-blue-600 text-sm md:text-base mt-2 inline-block">Visit Now</a>
                            </div>
                            <img loading="lazy" src="/assets/images/authorBbook/4.webp" alt="Author Books"
                                class="absolute -right-3 top-1/2 transform -translate-y-1/2 w-24 md:w-32">
                        </div>
                        <div class="swiper-slide relative">
                            <div class="w-full md:w-11/12 bg-white bg-opacity-60 py-6 px-5 shadow-lg rounded-lg">
                                <div class="flex flex-col md:flex-row gap-4 items-center">
                                    <img loading="lazy" class="w-16 h-16 md:w-20 md:h-20 object-cover rounded-full"
                                        src="/assets/images/home/client-placeholder.png" alt="Profile Picture">
                                    <div class="text-center md:text-left">
                                        <h3 class="text-lg md:text-xl font-medium">Angela Brown</h3>
                                        <p class="text-sm md:text-base font-normal">Harmony</p>
                                    </div>
                                </div>
                                <p class="text-sm md:text-base font-normal mt-4 md:mt-6">
                                   Abbie leaves the comfort of home behind. This adventure takes one woman into the mountains of West Virginia. A secluded rehabilitation center full of interesting people and sometimes amusing thought processes fuel...
                                </p>
                                <div class="mt-6">
                                    <h5 class="flex items-center gap-2 text-sm md:text-base font-medium">
                                        Published on <img loading="lazy" src="assets/images/Amazon-logo.png" alt="Amazon Logo"
                                            class="w-20">
                                    </h5>
                                </div>
                                <a href="https://www.amazon.com/dp/1961407035?ref_=cm_sw_r_cp_ud_dp_26QP2T13JKB9CZHPMHS7" class="text-blue-600 text-sm md:text-base mt-2 inline-block">Visit Now</a>
                            </div>
                            <img loading="lazy" src="/assets/images/authorBbook/5.webp" alt="Author Books"
                                class="absolute -right-3 top-1/2 transform -translate-y-1/2 w-24 md:w-32">
                        </div>
                        <div class="swiper-slide relative">
                            <div class="w-full md:w-11/12 bg-white bg-opacity-60 py-6 px-5 shadow-lg rounded-lg">
                                <div class="flex flex-col md:flex-row gap-4 items-center">
                                    <img loading="lazy" class="w-16 h-16 md:w-20 md:h-20 object-cover rounded-full"
                                        src="/assets/images/home/client-placeholder.png" alt="Profile Picture">
                                    <div class="text-center md:text-left">
                                        <h3 class="text-lg md:text-xl font-medium"> Brent Kunzler</h3>
                                        <p class="text-sm md:text-base font-normal">Follow Your Path</p>
                                    </div>
                                </div>
                                <p class="text-sm md:text-base font-normal mt-4 md:mt-6">
                                   This book takes readers on a journey of growth, challenges, failures, and triumphs From overcoming adversity to taking risks and forging meaningful relationships. My story is one of resilience and perseverance...
                                </p>
                                <div class="mt-6">
                                    <h5 class="flex items-center gap-2 text-sm md:text-base font-medium">
                                        Published on <img loading="lazy" src="assets/images/Amazon-logo.png" alt="Amazon Logo"
                                            class="w-20">
                                    </h5>
                                </div>
                                <a href="https://www.amazon.com/dp/B0CH2BLRLZ?ref_=cm_sw_r_cp_ud_dp_Y0PW8BAP5BQG7H2B3D85" class="text-blue-600 text-sm md:text-base mt-2 inline-block">Visit Now</a>
                            </div>
                            <img loading="lazy" src="/assets/images/authorBbook/6.webp" alt="Author Books"
                                class="absolute -right-3 top-1/2 transform -translate-y-1/2 w-24 md:w-32">
                        </div>
                        <div class="swiper-slide relative">
                            <div class="w-full md:w-11/12 bg-white bg-opacity-60 py-6 px-5 shadow-lg rounded-lg">
                                <div class="flex flex-col md:flex-row gap-4 items-center">
                                    <img loading="lazy" class="w-16 h-16 md:w-20 md:h-20 object-cover rounded-full"
                                        src="/assets/images/home/client-placeholder.png" alt="Profile Picture">
                                    <div class="text-center md:text-left">
                                        <h3 class="text-lg md:text-xl font-medium">Randall (Randy) Bucek</h3>
                                        <p class="text-sm md:text-base font-normal">Before I Wake</p>
                                    </div>
                                </div>
                                <p class="text-sm md:text-base font-normal mt-4 md:mt-6">
                                  I once met an angel, yet I must have been dreaming, As that which was before me had to be deceiving. She was a goddess in every form and fashion. Not missing was the beauty nor the purely innocent...
                                </p>
                                <div class="mt-6">
                                    <h5 class="flex items-center gap-2 text-sm md:text-base font-medium">
                                        Published on <img loading="lazy" src="assets/images/Amazon-logo.png" alt="Amazon Logo"
                                            class="w-20">
                                    </h5>
                                </div>
                                <a href="https://www.amazon.com/dp/B0CJZYTNL3?ref_=cm_sw_r_cp_ud_dp_NNSKAR10AXR8KGRYJ861" class="text-blue-600 text-sm md:text-base mt-2 inline-block">Visit Now</a>
                            </div>
                            <img loading="lazy" src="/assets/images/authorBbook/7.webp" alt="Author Books"
                                class="absolute -right-3 top-1/2 transform -translate-y-1/2 w-24 md:w-32">
                        </div>
                        <div class="swiper-slide relative">
                            <div class="w-full md:w-11/12 bg-white bg-opacity-60 py-6 px-5 shadow-lg rounded-lg">
                                <div class="flex flex-col md:flex-row gap-4 items-center">
                                    <img loading="lazy" class="w-16 h-16 md:w-20 md:h-20 object-cover rounded-full"
                                        src="/assets/images/home/client-placeholder.png" alt="Profile Picture">
                                    <div class="text-center md:text-left">
                                        <h3 class="text-lg md:text-xl font-medium">Graham Diamond & Hedy Campeas</h3>
                                        <p class="text-sm md:text-base font-normal">Diner of Lost Souls Book 2</p>
                                    </div>
                                </div>
                                <p class="text-sm md:text-base font-normal mt-4 md:mt-6">
                                    When a young woman is pushed in front of a bus and dies, Cora Drakos, sleuth and owner of the renowned Athena diner, is asked to help find out who did it and why. As she starts her investigation Cora...
                                </p>
                                <div class="mt-6">
                                    <h5 class="flex items-center gap-2 text-sm md:text-base font-medium">
                                        Published on <img loading="lazy" src="assets/images/Amazon-logo.png" alt="Amazon Logo"
                                            class="w-20">
                                    </h5>
                                </div>
                                <a href="https://www.amazon.com/dp/B0C6X68TVN?ref_=cm_sw_r_cp_ud_dp_E2JM7ZG6BK3AGDNP9DKV_1" class="text-blue-600 text-sm md:text-base mt-2 inline-block">Visit Now</a>
                            </div>
                            <img loading="lazy" src="/assets/images/authorBbook/8.webp" alt="Author Books"
                                class="absolute -right-3 top-1/2 transform -translate-y-1/2 w-24 md:w-32">
                        </div>
                        <div class="swiper-slide relative">
                            <div class="w-full md:w-11/12 bg-white bg-opacity-60 py-6 px-5 shadow-lg rounded-lg">
                                <div class="flex flex-col md:flex-row gap-4 items-center">
                                    <img loading="lazy" class="w-16 h-16 md:w-20 md:h-20 object-cover rounded-full"
                                        src="/assets/images/home/client-placeholder.png" alt="Profile Picture">
                                    <div class="text-center md:text-left">
                                        <h3 class="text-lg md:text-xl font-medium"> Ivan Jr Molina</h3>
                                        <p class="text-sm md:text-base font-normal">Spiritual Laziness</p>
                                    </div>
                                </div>
                                <p class="text-sm md:text-base font-normal mt-4 md:mt-6">
                                   Born in Bridgeport, Connecticut, to Puerto Rican parents, Ivan Molina, Jr., is a Florida-based Gospel Hip-Hop artist performing with his wife Brandi under the name Inner Light. Together they have released one album...
                                </p>
                                <div class="mt-6">
                                    <h5 class="flex items-center gap-2 text-sm md:text-base font-medium">
                                        Published on <img loading="lazy" src="assets/images/Amazon-logo.png" alt="Amazon Logo"
                                            class="w-20">
                                    </h5>
                                </div>
                                <a href="https://www.amazon.com/dp/1961407280?ref_=cm_sw_r_cp_ud_dp_W0MJRD5X0V9AG4E05FVP" class="text-blue-600 text-sm md:text-base mt-2 inline-block">Visit Now</a>
                            </div>
                            <img loading="lazy" src="/assets/images/authorBbook/9.webp" alt="Author Books"
                                class="absolute -right-3 top-1/2 transform -translate-y-1/2 w-24 md:w-32">
                        </div>
                        <div class="swiper-slide relative">
                            <div class="w-full md:w-11/12 bg-white bg-opacity-60 py-6 px-5 shadow-lg rounded-lg">
                                <div class="flex flex-col md:flex-row gap-4 items-center">
                                    <img loading="lazy" class="w-16 h-16 md:w-20 md:h-20 object-cover rounded-full"
                                        src="/assets/images/home/client-placeholder.png" alt="Profile Picture">
                                    <div class="text-center md:text-left">
                                        <h3 class="text-lg md:text-xl font-medium">John Randall Meulman</h3>
                                        <p class="text-sm md:text-base font-normal">Her Shattered Wings</p>
                                    </div>
                                </div>
                                <p class="text-sm md:text-base font-normal mt-4 md:mt-6">
                                   Shattered Wings is more than a suspense thriller about a brutal rapist and his victim. It is a hard look at the courts and our legal system. This intense, fast paced novel takes you into the mind of Julie Stevenson whose world is shattered by horrifying violence...
                                </p>
                                <div class="mt-6">
                                    <h5 class="flex items-center gap-2 text-sm md:text-base font-medium">
                                        Published on <img loading="lazy" src="assets/images/Amazon-logo.png" alt="Amazon Logo"
                                            class="w-20">
                                    </h5>
                                </div>
                                <a href="https://www.amazon.com/dp/1961407485?ref_=cm_sw_r_cp_ud_dp_YRJSFTYE7D1RR6E962KK" class="text-blue-600 text-sm md:text-base mt-2 inline-block">Visit Now</a>
                            </div>
                            <img loading="lazy" src="/assets/images/authorBbook/10.webp" alt="Author Books"
                                class="absolute -right-3 top-1/2 transform -translate-y-1/2 w-24 md:w-32">
                        </div>
                        <!-- End of Swiper Slide -->
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-24 bg-[url(/assets/images/home/usman-sec-bg.png)] bg-top bg-cover bg-no-repeat">
        <div class="grid md:grid-cols-12 px-2 grid-cols-1 sm:px-[80px] items-start !gap-5">
            <div class="sm:col-span-7">
                <h3 class="text-[24px] sm:pr-28 font-[600] leading-[30px] ">Our Amazon Book Publishing Services <span
                        class="capitalize text-[var(--theme2)]">Have Given Numerous Authors and Publishers </span>the
                    Chance to Excel.</h3>
                <p class="mt-4"> Our Book Publishing Company Encompass A Variety Of Offerings Designed
                    To Assist Authors And Publishers In The Process Of Creating And
                    Distributing Their Books. Our Services Include:</p>
            </div>
            
            <button onclick="toggleModal()"
                class="gradientBg sm:col-span-2 text-white h-12 w-full md:w-44 justify-center rounded-xl text-sm flex gap-1 items-center">
                Get Started Today
                <i class="fa fa-angle-right"></i>
            </button>
            
            <!--<div class="flex gap-2 sm:col-span-3 items-center mt-0">-->
            <!--    <div-->
            <!--        class="flex justify-center items-center h-11 w-11 rounded-full border border-black !text-black rotate-90 m-0">-->
            <!--        <i class="fa fa-phone" aria-hidden="true"></i>-->
            <!--    </div>-->
            <!--    <div class="flex flex-col justify-between text-black m-0">-->
            <!--        <div class="text-lg m-0 p-0">Call Us</div>-->
            <!--        <a href="tel:+18337471898" class="text-sm m-0 p-0">+1 (833) 747-1898</a>-->
            <!--    </div>-->
            <!--</div>-->

        </div>
        <div
            class="grid sm:grid-cols-3 grid-cols-1 grid-rows-2 sm:mt-14 mt-20 sm:pl-[150px] px-4 sm:pr-[150px] gap-x-5 gap-y-16">
            <div
                class="bg-white hover:bg-[radial-gradient(circle,rgba(62,191,194,1)_0%,rgba(255,255,255,1)_100%)] rounded-xl py-[28px] px-[14px] serviceBox group relative">
                <div
                    class="absolute -top-14 left-[50%] right-[50%] -translate-x-[50%] group w-[100px] h-[100px] rounded-full bg-[#b8e4f0] flex items-center justify-center transition-colors duration-100 group-hover:bg-[#1e3a8a]">
                    <img loading="lazy" src="/assets/images/home/1.png" alt="Lightbulb Icon" class="w-3/4 h-3/4" />
                </div>
                <h1 class="text-[20px] font-[600] px-14 text-[#0A6688] text-center mt-10">Editing and
                    Proofreading</h1>
                <p class="text-[14px] font-[400] px-7 mt-2 text-center">We assist writers with polishing and
                    rewriting their works to make sure there are no mistakes or errors.</p>
            </div>
            <div
                class="bg-white hover:bg-[radial-gradient(circle,rgba(62,191,194,1)_0%,rgba(255,255,255,1)_100%)] rounded-xl py-[28px] px-[14px] serviceBox group relative">
                <div
                    class="absolute -top-14 left-[50%] right-[50%] -translate-x-[50%] group w-[100px] h-[100px] rounded-full bg-[#b8e4f0] flex items-center justify-center transition-colors duration-100 group-hover:bg-[#1e3a8a]">
                    <img loading="lazy" src="/assets/images/home/1.png" alt="Lightbulb Icon" class="w-3/4 h-3/4" />
                </div>
                <h1 class="text-[20px] font-[600] px-14 text-[#0A6688] text-center mt-10">Cover Design and
                    Layout</h1>
                <p class="text-[14px] font-[400] px-7 mt-2 text-center">We can assist authors in creating visually
                    appealing book covers that express the tone of their writing by offering cover design and layout
                    services.</p>
            </div>
            <div
                class="bg-white hover:bg-[radial-gradient(circle,rgba(62,191,194,1)_0%,rgba(255,255,255,1)_100%)] rounded-xl py-[28px] px-[14px] serviceBox group relative">
                <div
                    class="absolute -top-14 left-[50%] right-[50%] -translate-x-[50%] group w-[100px] h-[100px] rounded-full bg-[#b8e4f0] flex items-center justify-center transition-colors duration-100 group-hover:bg-[#1e3a8a]">
                    <img loading="lazy" src="/assets/images/home/1.png" alt="Lightbulb Icon" class="w-3/4 h-3/4" />
                </div>
                <h1 class="text-[20px] font-[600] px-14 text-[#0A6688] text-center mt-10">Formatting And Conversion
                </h1>
                <p class="text-[14px] font-[400] px-7 mt-2 text-center">These services will help writers in
                    formatting their manuscripts effectively transforming them into multiple formats, such as
                    audiobooks and e-books.</p>
            </div>
            <div
                class="bg-white hover:bg-[radial-gradient(circle,rgba(62,191,194,1)_0%,rgba(255,255,255,1)_100%)] rounded-xl py-[28px] px-[14px] serviceBox group relative">
                <div
                    class="absolute -top-14 left-[50%] right-[50%] -translate-x-[50%] group w-[100px] h-[100px] rounded-full bg-[#b8e4f0] flex items-center justify-center transition-colors duration-100 group-hover:bg-[#1e3a8a]">
                    <img loading="lazy" src="/assets/images/home/1.png" alt="Lightbulb Icon" class="w-3/4 h-3/4" />
                </div>
                <h1 class="text-[20px] font-[600] px-14 text-[#0A6688] text-center mt-10">Printing and
                    Distribution</h1>
                <p class="text-[14px] font-[400] px-7 mt-2 text-center">Our printing and distribution services help
                    publishers and writers in creating hard copies of their books and distributing them to
                    retailers, libraries, and bookstores.</p>
            </div>
            <div
                class="bg-white hover:bg-[radial-gradient(circle,rgba(62,191,194,1)_0%,rgba(255,255,255,1)_100%)] rounded-xl py-[28px] px-[14px] serviceBox group relative">
                <div
                    class="absolute -top-14 left-[50%] right-[50%] -translate-x-[50%] group w-[100px] h-[100px] rounded-full bg-[#b8e4f0] flex items-center justify-center transition-colors duration-100 group-hover:bg-[#1e3a8a]">
                    <img loading="lazy" src="/assets/images/home/1.png" alt="Lightbulb Icon" class="w-3/4 h-3/4" />
                </div>
                <h1 class="text-[20px] font-[600] px-14 text-[#0A6688] text-center mt-10">Marketing And
                    Support</h1>
                <p class="text-[14px] font-[400] px-7 mt-2 text-center">We help publishers and authors sell their
                    books to targeted readers using a variety of platforms, including text tours, email marketing,
                    and social media.</p>
            </div>
            <div
                class="bg-white hover:bg-[radial-gradient(circle,rgba(62,191,194,1)_0%,rgba(255,255,255,1)_100%)] rounded-xl py-[28px] px-[14px] serviceBox group relative">
                <div
                    class="absolute -top-14 left-[50%] right-[50%] -translate-x-[50%] group w-[100px] h-[100px] rounded-full bg-[#b8e4f0] flex items-center justify-center transition-colors duration-100 group-hover:bg-[#1e3a8a]">
                    <img loading="lazy" src="/assets/images/home/1.png" alt="Lightbulb Icon" class="w-3/4 h-3/4" />
                </div>
                <h1 class="text-[20px] font-[600] px-14 text-[#0A6688] text-center mt-10">Copyrights and Legal
                    Services</h1>
                <p class="text-[14px] font-[400] px-7 mt-2 text-center">Authors and publishers can secure their
                    intellectual property and guarantee that their publications are released in a morally and
                    legally responsible manner by utilizing copyright registration and legal compliance services.
                </p>
            </div>

        </div>

    </section>

    <section class="md:w-[80%] w-[90%] mx-auto mt-24 grid md:grid-cols-2 items-center">
        <div>
            <div class="flex items-end gap-2">
                <img loading="lazy" src="/assets/images/home/pen-about.png" alt="pen">
                <h5 class="text-[var(--theme2)]">Why Choose Us</h5>
            </div>
            <h3 class="text-[30px] font-[600] leading-[42px] mt-4 ">Why Select Our <span
                    class="capitalize text-[var(--theme2)]">Book Publishing Services </span>in USA?</h3>
            <p class="mt-3 text-sm">
                We believe in professionals who leverage their versatility and extensive experience across various
                academic disciplines, such as arts, business, technology, advertising, communications, social sciences,
                and engineering. Our publishers specialize in strategic planning, ideation, consulting, and proactive
                communication with clients to deliver a finely crafted product. At Manorbookpublishers, we prioritize
                original publishing with precision to yield tangible results. Our best book publishing company is
                powered by experienced publishers, featuring a dedicated team of full-time publishers, managers,
                proofreaders, and quality assurance experts.


            </p>
            <div class="flex md:gap-20 gap-2 items-center mt-5">
                
                <button onclick="toggleModal()"
                    class="gradientBg text-white h-[50px] w-[170px] justify-center rounded-xl text-sm flex gap-1 items-center">
                    Get Started Today
                    <i class="fa fa-angle-right"></i>
                </button>
                
                <div class="flex gap-2 items-center">
                    <div
                        class="flex justify-center items-center h-11 w-11 rounded-full border border-black !text-black rotate-90">
                        <i class="fa fa-phone" aria-hidden="true"></i>
                    </div>
                    <div class="flex flex-col justify-between text-black">
                        <div class="text-lg">Call Us</div>
                        <a href="tel:+18337471898" class="text-sm">+1 (833) 747-1898</a>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <dotlottie-player src="https://lottie.host/74bf35ff-d951-4ff1-a2e5-5e929f8a57e5/FVOllfZ9b4.json"
                background="transparent" speed="1" loop="" autoplay="" class="h-auto w-full mx-auto"></dotlottie-player>
        </div>
    </section>

    <section
        class="md:w-[85%] w-full mx-auto mt-24 bg-[url(/assets/images/home/tab-sec-bg.png)] px-7 py-14 relative bg-cover bg-no-repeat bg-left-top pl-10">
        <div class="md:w-[78%]">
            <div class="md:flex">
                <h1 class="md:w-[72%] text-[30px] font-[600] text-white">Our Success Formula Involves Creativity,
                    Passion, and Strategic Execution</h1>
                <div class="space-y-6">
                   
                    <button onclick="toggleModal()"
                        class="gradientBg text-white h-[50px] w-[170px] justify-center rounded-xl text-sm flex gap-1 items-center">
                        Get Started Today
                        <i class="fa fa-angle-right"></i>
                    </button>
                    
                    <div class="flex gap-2 items-center">
                        <div
                            class="flex justify-center items-center h-11 w-11 rounded-full border border-white !text-white rotate-90">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                        </div>
                        <div class="flex flex-col justify-between text-white">
                            <div class="text-lg">Call Us</div>
                            <a href="tel:+18337471898" class="text-sm">+1 (833) 747-1898</a>
                        </div>
                    </div>
                </div>
            </div>
            <div id="tabs" class="grid md:grid-cols-6 grid-cols-3 items-center mt-12 md:gap-y-0 gap-y-5">
                <div class="flex gap-2 items-center">
                    <img loading="lazy" onclick="setActiveTab(0)" src="/assets/images/home/success/1.png" alt="creative"
                        class="w-[75px] h-[75px] bg-[#89deed] p-2 rounded-full cursor-pointer tab-image">
                    <img loading="lazy" src="/assets/images/home/success/tab-arrow.png" class="h-4">
                </div>
                <div class="flex gap-2 items-center">
                    <img loading="lazy" onclick="setActiveTab(1)" src="/assets/images/home/success/2.png" alt="creative"
                        class="w-[75px] h-[75px] bg-[#89deed] p-2 rounded-full cursor-pointer tab-image">
                    <img loading="lazy" src="/assets/images/home/success/tab-arrow.png" class="h-4">
                </div>
                <div class="flex gap-2 items-center">
                    <img loading="lazy" onclick="setActiveTab(2)" src="/assets/images/home/success/3.png" alt="creative"
                        class="w-[75px] h-[75px] bg-[#89deed] p-2 rounded-full cursor-pointer tab-image">
                    <img loading="lazy" src="/assets/images/home/success/tab-arrow.png" class="h-4">
                </div>
                <div class="flex gap-2 items-center">
                    <img loading="lazy" onclick="setActiveTab(3)" src="/assets/images/home/success/4.png" alt="creative"
                        class="w-[75px] h-[75px] bg-[#89deed] p-2 rounded-full cursor-pointer tab-image">
                    <img loading="lazy" src="/assets/images/home/success/tab-arrow.png" class="h-4">
                </div>
                <div class="flex gap-2 items-center">
                    <img loading="lazy" onclick="setActiveTab(4)" src="/assets/images/home/success/5.png" alt="creative"
                        class="w-[75px] h-[75px] bg-[#89deed] p-2 rounded-full cursor-pointer tab-image">
                    <img loading="lazy" src="/assets/images/home/success/tab-arrow.png" class="h-4">
                </div>
                <div class="flex gap-2 items-center">
                    <img loading="lazy" onclick="setActiveTab(5)" src="/assets/images/home/success/6.png" alt="creative"
                        class="w-[75px] h-[75px] bg-[#89deed] p-2 rounded-full cursor-pointer tab-image">
                </div>
            </div>
            <div id="tab-content" class="mt-8 min-h-20">
                <div class="grid md:grid-cols-6 gap-2">
                    <div class="md:col-span-2">
                        <h1 id="tab-title" class="font-semibold text-[24px] text-white leading-[32px] font-semibold">
                            Creative Vision and Tactical
                            Execution</h1>
                    </div>
                    <div class="md:col-span-4">
                        <p id="tab-description" class="text-[13px] font-[400] text-white md:w-[93%]">We have a board of
                            well-versed book publishers who
                            conduct thorough research when it comes to book publishing solutions. In order to understand
                            the
                            requirements of the client properly, we ask several questions, then add our creative vision
                            and
                            execute it tactically.</p>
                    </div>
                </div>
            </div>
            <img loading="lazy" src="/assets/images/home/tab-sec-book.webp" alt="tab-sec-book"
                class="absolute -right-20 top-0 md:h-[118%] h-0">
        </div>
    </section>

    <section class="grid md:grid-cols-2 gap-8 mt-24">
        <div class="bg-[url(/assets/images/home/process-bg.png)] bg-center bg-contain bg-no-repeat">
            <div class="grid grid-cols-2 grid-rows-2 md:w-[80%] w-[95%] mx-auto md:mr-0 md:ml-auto gap-2">
                <div class="bg-white rounded-xl py-[28px] px-[14px] serviceBox group">
                    <h1
                        class="text-[40px] font-[400] text-white text-center bg-[url(/assets/images/home/process-num-bg.png)] group-hover:bg-[url(/assets/images/home/process-num-bghover.png)] bg-[92px] bg-no-repeat w-full bg-top py-[25px]">
                        01</h1>
                    <h1 class="text-[16px] font-[600] text-center my-2">Best Percentages</h1>
                    <span class="process-divider">
                        <div class="dividers-process"></div>
                    </span>
                    <p class="text-[14px] font-[400] text-center">Regardless of your level of experience, we will assist
                        in paving the path to success..</p>
                </div>
                <div class="bg-white rounded-xl py-[28px] px-[14px] serviceBox group">
                    <h1
                        class="text-[40px] font-[400] text-white text-center bg-[url(/assets/images/home/process-num-bg.png)] group-hover:bg-[url(/assets/images/home/process-num-bghover.png)] bg-[92px] bg-no-repeat w-full bg-top py-[25px]">
                        02</h1>
                    <h1 class="text-[16px] font-[600] text-center my-2">Transparency</h1>
                    <span class="process-divider">
                        <div class="dividers-process"></div>
                    </span>
                    <p class="text-[14px] font-[400] text-center">You can see every step of the procedure in full
                        transparency. You'll be aware of what your editor.</p>
                </div>
                <div class="bg-white rounded-xl py-[28px] px-[14px] serviceBox group">
                    <h1
                        class="text-[40px] font-[400] text-white text-center bg-[url(/assets/images/home/process-num-bg.png)] group-hover:bg-[url(/assets/images/home/process-num-bghover.png)] bg-[92px] bg-no-repeat w-full bg-top py-[25px]">
                        03</h1>
                    <h1 class="text-[16px] font-[600] text-center my-2">24/7 Support</h1>
                    <span class="process-divider">
                        <div class="dividers-process"></div>
                    </span>
                    <p class="text-[14px] font-[400] text-center">No matter what time of day, we are always available to
                        you and have answers to any questions you may have.
                    </p>
                </div>
                <div class="bg-white rounded-xl py-[28px] px-[14px] serviceBox group">
                    <h1
                        class="text-[40px] font-[400] text-white text-center bg-[url(/assets/images/home/process-num-bg.png)] group-hover:bg-[url(/assets/images/home/process-num-bghover.png)] bg-[92px] bg-no-repeat w-full bg-top py-[25px]">
                        04</h1>
                    <h1 class="text-[16px] font-[600] text-center my-2">Publishing Trends</h1>
                    <span class="process-divider">
                        <div class="dividers-process"></div>
                    </span>
                    <p class="text-[14px] font-[400] text-center">
                        Our publishing staff stays abreast of the most recent developments in this field on a regular
                        basis.
                    </p>
                </div>
            </div>
        </div>
        <div class="md:w-[77%] w-[95%] md:mx-0 mx-auto md:mt-0 mt-5">
            <div class="flex items-end gap-2">
                <img loading="lazy" src="/assets/images/home/pen-about.png" alt="pen">
                <h5 class="text-[var(--theme2)] font-[600]">Our Process</h5>
            </div>
            <div>
                <h3 class="text-[26px] font-[600] leading-[42px] mt-4 ">With the help of Amazon <span
                        class="capitalize text-[var(--theme2)]">Book Publishing Services, </span>Tell the World Your
                    Story</h3>
                <p class="mt-3 text-[14px]">With the help of book publishing services, we help innumerable authors
                    become bestsellers. Some of the most well-known authors of all time use the platform to share their
                    works.</p>
            </div>
            <div>
                <h3 class="text-[26px] font-[600] leading-[42px] mt-3 ">Consul<span
                        class="text-[var(--theme2)]">tancy</span></h3>
                <p class="mt-2 text-[14px]">We are here to address any inquiries you may have concerning self-publishing
                    your book. We'll make sure everything is simple and assist in guiding the process.</p>
            </div>
            <div>
                <h3 class="text-[26px] font-[600] leading-[42px] mt-3 ">Leading Literary <span
                        class="text-[var(--theme2)]">Agents</span></h3>
                <p class="mt-2 text-[14px]">Our goal is to assist you in locating the ideal fit for your undertaking.
                    We'll put you in touch with agents who are eager to perform at the highest level.</p>
            </div>
            <div class="flex md:gap-20 gap-2 items-center mt-9">
                
                <button onclick="toggleModal()"
                    class="gradientBg text-white h-[50px] w-[170px] justify-center rounded-xl text-sm flex gap-1 items-center">
                    Get Started Today
                    <i class="fa fa-angle-right"></i>
                </button>
                
                <div class="flex gap-2 items-center">
                    <div
                        class="flex justify-center items-center h-11 w-11 rounded-full border border-black !text-black rotate-90">
                        <i class="fa fa-phone" aria-hidden="true"></i>
                    </div>
                    <div class="flex flex-col justify-between text-black">
                        <div class="text-lg">Call Us</div>
                        <a href="tel:+18337471898" class="text-sm">+1 (833) 747-1898</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section
        class="md:w-[85%] w-full m-auto mt-24 md:rounded-lg !rounded-0 bg-[url(assets/images/home/newsletter-bg.png)] py-14 grid md:grid-cols-2 items-center text-white md:gap-0 gap-8 bg-no-repeat bg-cover">
        <h1 class="md:text-[40px] text-2xl font-[600] text-center">Subscribe To <span
                class="text-[#3ebfc2]">Newsletter</span>
        </h1>
        <form id="newsletter" class="grid grid-cols-2 gap-3 bg-white rounded-lg items-center md:w-[80%] w-[92%] mx-auto md:p-3">
            <input type="email" name="email" placeholder="Enter Your Email" class="py-4 px-2 text-black focus:outline-none">
            <button type="submit" class="text-white gradientBg h-full md:rounded-lg py-4">Subscribe</button>
        </form>
    </section>

    <!-- <section class="mt-24 md:w-[85vw] w-[95vw] mx-auto">
        <h1 class="w-fit text-center md:text-[40px] text-4xl capitalize mx-auto font-[600]">
            What Clients Says about
            <span class="text-[var(--theme2)] leading-[45px]">Manorbookpublishers</span>
        </h1>
        <div class="swiper mySwiper3 mt-11 relative">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="test-item grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <img loading="lazy" src="assets/images/7.webp" alt="test-1">
                        </div>
                        <div class="p-6">
                            <blockquote class="text-[#0A6697] text-[24px] font-[600]">"A Seamless Experience from Start
                                to Finish!"
                            </blockquote>
                            <p class="mt-4 text-muted-foreground">
                                Working with Manorbookpublishers completely transformed my self-publishing journey. Their
                                comprehensive editing and design services ensured my ebook looked professional and was
                                free of errors. The marketing support helped me reach a wider audience, and I saw a
                                significant increase in sales within the first month of launch. I couldn't have done it
                                without their expertise and dedication!
                            </p>
                            <div class="flex items-center mt-6">
                                <img loading="lazy" class="w-12 h-12 rounded-full" src="assets/images/barbara.webp"
                                    alt="Steven D. Henry" />
                                <div class="ml-4">
                                    <p class="font-medium text-primary-foreground">Sarah J. Miller, Marketing Head</p>
                                    <p class="text-sm text-muted-foreground">GreenSky Solutions</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="test-item grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <img loading="lazy" src="assets/images/2.webp" alt="test-2">
                        </div>
                        <div class="p-6">
                            <blockquote class="text-[#0A6697] text-[24px] font-[600]">"Creative, Reliable, and Always
                                On-Time!"
                            </blockquote>
                            <p class="mt-4 text-muted-foreground">
                                As a small business owner, creating informative ebooks was essential for my content
                                marketing strategy. Manorbookpublishers made the entire process seamless—from concept
                                development to distribution. Their team was responsive, creative, and delivered
                                high-quality work on time. Thanks to their services, I've been able to establish my
                                brand as an authority in my industry.
                            </p>
                            <div class="flex items-center mt-6">
                                <img loading="lazy" class="w-12 h-12 rounded-full" src="assets/images/ashlay.webp" alt="Jane S. Doe" />
                                <div class="ml-4">
                                    <p class="font-medium text-primary-foreground">Michael D. Carter, Owner</p>
                                    <p class="text-sm text-muted-foreground">UrbanClick Agency</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="test-item grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <img loading="lazy" src="assets/images/6.webp" alt="test-3">
                        </div>
                        <div class="p-6">
                            <blockquote class="text-[#0A6697] text-[24px] font-[600]">"They Understood Our Vision
                                Perfectly!"
                            </blockquote>
                            <p class="mt-4 text-muted-foreground">
                                I approached Manorbookpublishers to help turn my educational blog posts into a
                                comprehensive ebook. They provided invaluable guidance on structuring the content,
                                designing an engaging layout, and formatting it for various platforms. The final product
                                exceeded my expectations and has been a fantastic resource for my students and
                                followers. Highly recommend their professional and friendly services!
                            </p>
                            <div class="flex items-center mt-6">
                                <img loading="lazy" class="w-12 h-12 rounded-full" src="assets/images/steven.webp" alt="Mark T. Lee" />
                                <div class="ml-4">
                                    <p class="font-medium text-primary-foreground">Linda K. Williams, Founder</p>
                                    <p class="text-sm text-muted-foreground">BlueTrail Ventures</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-pagination z-50 absolute !left-[90%] !bottom-10 !w-fit"></div>
        </div>
    </section> -->

    <section class="mt-24 mb-16">
        <h1 class="md:ml-[7vw] ml-[2vw] text-[40px] text-center mb-8 font-[600] leading-[42px]">
            Feedbacks & <span class="capitalize text-[var(--theme2)]">Testimonials</span>
        </h1>
        <div class="swiper mySwiper3 relative px-[2vw] mt-5">
            <div class="swiper-wrapper pb-20">
                <div class="swiper-slide md:mx-5">
                    <div class="pt-14">
                        <div
                            class="bg-white rounded-2xl relative rounded-5 pb-3 pl-[20px] pr-[10px] shadowTestimonials">
                            <img loading="lazy" src="/assets/images/home/client-01.png" alt="Client"
                                class="h-24 absolute -top-12 left-8">
                            <div class="pt-20"></div>
                            <p class="text-[13px] font-[400] leading-[20px] overflow-y-scroll h-[100px] pr-[10px]">Very
                                cooperative staff. They were able to understand my complex project requirements and
                                deliver everything on time.</p>
                            <div class="mt-4 flex justify-between items-center">
                                <h3 class="text-[20px] font-[600]">William</h3>
                                <img loading="lazy" src="/assets/images/home/stars.png" alt="Stars">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide md:mx-5 mt-16">
                    <div class="pt-14">
                        <div
                            class="bg-white rounded-2xl relative rounded-5 pb-3 pl-[20px] pr-[10px] shadowTestimonials">
                            <img loading="lazy" src="/assets/images/home/client-02.png" alt="Client"
                                class="h-24 absolute -top-12 left-8">
                            <div class="pt-20"></div>
                            <p class="text-[13px] font-[400] leading-[20px] overflow-y-scroll h-[100px] pr-[10px]">Best
                                book writing professionals I have came across in USA. They delivered everything they had
                                promised. Very satisfied.</p>
                            <div class="mt-4 flex justify-between items-center">
                                <h3 class="text-[20px] font-[600]">James</h3>
                                <img loading="lazy" src="/assets/images/home/stars.png" alt="Stars">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide md:mx-5">
                    <div class="pt-14">
                        <div
                            class="bg-white rounded-2xl relative rounded-5 pb-3 pl-[20px] pr-[10px] shadowTestimonials">
                            <img loading="lazy" src="/assets/images/home/client-03.png" alt="Client"
                                class="h-24 absolute -top-12 left-8">
                            <div class="pt-20"></div>
                            <p class="text-[13px] font-[400] leading-[20px] overflow-y-scroll h-[100px] pr-[10px]">I was
                                skeptic at first but after talking to Adam and conveying all my queries, I received
                                better quality work than I had imagined. I recommend their services to everyone out
                                there.</p>
                            <div class="mt-4 flex justify-between items-center">
                                <h3 class="text-[20px] font-[600]">Rabeeca</h3>
                                <img loading="lazy" src="/assets/images/home/stars.png" alt="Stars">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide md:mx-5 mt-16">
                    <div class="pt-14">
                        <div
                            class="bg-white rounded-2xl relative rounded-5 pb-3 pl-[20px] pr-[10px] shadowTestimonials">
                            <img loading="lazy" src="/assets/images/home/client-04.png" alt="Client"
                                class="h-24 absolute -top-12 left-8">
                            <div class="pt-20"></div>
                            <p class="text-[13px] font-[400] leading-[20px] overflow-y-scroll h-[100px] pr-[10px]">1. To
                                publish my book, I needed a hassle-free book publishing plan. My sales have increased
                                ever since this website accomplished far more than it promised</p>
                            <div class="mt-4 flex justify-between items-center">
                                <h3 class="text-[20px] font-[600]">Steven</h3>
                                <img loading="lazy" src="/assets/images/home/stars.png" alt="Stars">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide md:mx-5">
                    <div class="pt-14">
                        <div
                            class="bg-white rounded-2xl relative rounded-5 pb-3 pl-[20px] pr-[10px] shadowTestimonials">
                            <img loading="lazy" src="/assets/images/home/client-05.png" alt="Client"
                                class="h-24 absolute -top-12 left-8">
                            <div class="pt-20"></div>
                            <p class="text-[13px] font-[400] leading-[20px] overflow-y-scroll h-[100px] pr-[10px]">Very
                                cooperative staff. They were able to understand my complex project requirements and
                                deliver everything on time.</p>
                            <div class="mt-4 flex justify-between items-center">
                                <h3 class="text-[20px] font-[600]">Thomas</h3>
                                <img loading="lazy" src="/assets/images/home/stars.png" alt="Stars">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide md:mx-5 mt-16">
                    <div class="pt-14">
                        <div
                            class="bg-white rounded-2xl relative rounded-5 pb-3 pl-[20px] pr-[10px] shadowTestimonials">
                            <img loading="lazy" src="/assets/images/home/client-06.png" alt="Client"
                                class="h-24 absolute -top-12 left-8">
                            <div class="pt-20"></div>
                            <p class="text-[13px] font-[400] leading-[20px] overflow-y-scroll h-[100px] pr-[10px]">Best
                                book writing professionals I have came across in USA. They delivered everything they had
                                promised. Very satisfied.</p>
                            <div class="mt-4 flex justify-between items-center">
                                <h3 class="text-[20px] font-[600]">Emily</h3>
                                <img loading="lazy" src="/assets/images/home/stars.png" alt="Stars">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide md:mx-5">
                    <div class="pt-14">
                        <div
                            class="bg-white rounded-2xl relative rounded-5 pb-3 pl-[20px] pr-[10px] shadowTestimonials">
                            <img loading="lazy" src="/assets/images/home/client-07.png" alt="Client"
                                class="h-24 absolute -top-12 left-8">
                            <div class="pt-20"></div>
                            <p class="text-[13px] font-[400] leading-[20px] overflow-y-scroll h-[100px] pr-[10px]">Very
                                cooperative staff. They were able to understand my complex project requirements and
                                deliver everything on time.</p>
                            <div class="mt-4 flex justify-between items-center">
                                <h3 class="text-[20px] font-[600]">Michael</h3>
                                <img loading="lazy" src="/assets/images/home/stars.png" alt="Stars">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide md:mx-5 mt-16">
                    <div class="pt-14">
                        <div
                            class="bg-white rounded-2xl relative rounded-5 pb-3 pl-[20px] pr-[10px] shadowTestimonials">
                            <img loading="lazy" src="/assets/images/home/client-08.png" alt="Client"
                                class="h-24 absolute -top-12 left-8">
                            <div class="pt-20"></div>
                            <p class="text-[13px] font-[400] leading-[20px] overflow-y-scroll h-[100px] pr-[10px]">Best
                                book writing professionals I have came across in USA. They delivered everything they had
                                promised. Very satisfied.</p>
                            <div class="mt-4 flex justify-between items-center">
                                <h3 class="text-[20px] font-[600]">Oliver</h3>
                                <img loading="lazy" src="/assets/images/home/stars.png" alt="Stars">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide md:mx-5">
                    <div class="pt-14">
                        <div
                            class="bg-white rounded-2xl relative rounded-5 pb-3 pl-[20px] pr-[10px] shadowTestimonials">
                            <img loading="lazy" src="/assets/images/home/client-09.png" alt="Client"
                                class="h-24 absolute -top-12 left-8">
                            <div class="pt-20"></div>
                            <p class="text-[13px] font-[400] leading-[20px] overflow-y-scroll h-[100px] pr-[10px]">Very
                                cooperative staff. They were able to understand my complex project requirements and
                                deliver everything on time.</p>
                            <div class="mt-4 flex justify-between items-center">
                                <h3 class="text-[20px] font-[600]">Richard</h3>
                                <img loading="lazy" src="/assets/images/home/stars.png" alt="Stars">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide md:mx-5 mt-16">
                    <div class="pt-14">
                        <div
                            class="bg-white rounded-2xl relative rounded-5 pb-3 pl-[20px] pr-[10px] shadowTestimonials">
                            <img loading="lazy" src="/assets/images/home/client-10.png" alt="Client"
                                class="h-24 absolute -top-12 left-8">
                            <div class="pt-20"></div>
                            <p class="text-[13px] font-[400] leading-[20px] overflow-y-scroll h-[100px] pr-[10px]">Best
                                book writing professionals I have came across in USA. They delivered everything they had
                                promised. Very satisfied.</p>
                            <div class="mt-4 flex justify-between items-center">
                                <h3 class="text-[20px] font-[600]">Marry</h3>
                                <img loading="lazy" src="/assets/images/home/stars.png" alt="Stars">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-pagination !mt-10"></div>
        </div>
    </section>

    <section class="faq mt-16 py-16">
        <div class="max-w-4xl mx-auto md:w-auto w-[92%]">
            <h2 class="text-4xl font-semibold text-center text-gray-800 mb-5">
                Frequently <span class="text-[var(--theme2)] !border-b-[var(--theme2)] !border-b-2">Asked</span>
                Questions
            </h2>
            <p class="text-center text-gray-600 mb-10">
                Here is a list of frequently asked questions about our book writing service.
            </p>

            <!-- FAQ Item 1 -->
            <div class="faq-item">
                <button onclick="toggleFAQ(1)" class="focus:outline-none p-5">
                    <span class="text-left md:text-center">How many days do you mainly take to complete a book
                        project?</span>
                    <span id="icon-1">+</span>
                </button>
                <div id="faq-1" class="faq-answer">
                    Turnover mainly depends on the depth of your project. However, our team of professional writers try
                    their
                    best to wrap up your project as soon as they can while maintaining the quality of our work.
                </div>
            </div>

            <!-- FAQ Item 2 -->
            <div class="faq-item">
                <button onclick="toggleFAQ(2)" class="focus:outline-none p-5">
                    <span class="text-left md:text-center">What book genres do you mainly cater?</span>
                    <span id="icon-2">+</span>
                </button>
                <div id="faq-2" class="faq-answer">
                    Our professional book writing team cater to all book genres. We have a board of professional book
                    writers
                    for different domains who are capable to write on all genres.
                </div>
            </div>

            <!-- FAQ Item 3 -->
            <div class="faq-item">
                <button onclick="toggleFAQ(3)" class="focus:outline-none p-5">
                    <span class="text-left md:text-center">Do you offer a guarantee for the services you are
                        offering?</span>
                    <span id="icon-3">+</span>
                </button>
                <div id="faq-3" class="faq-answer">
                    Being in this domain for over 10 years, we have gathered the experience and expertise to cater to
                    all
                    book writing projects, no matter how complex they are. Hence, we give our clients a guarantee for
                    the
                    services we are offering.
                </div>
            </div>

            <!-- FAQ Item 4 -->
            <div class="faq-item">
                <button onclick="toggleFAQ(4)" class="focus:outline-none p-5">
                    <span class="text-left md:text-center">Do you give revisions?</span>
                    <span id="icon-4">+</span>
                </button>
                <div id="faq-4" class="faq-answer">
                    Client's satisfaction is our priority which is why we give revisions until the client is fully
                    satisfied.
                </div>
            </div>

            <!-- FAQ Item 5 -->
            <div class="faq-item">
                <button onclick="toggleFAQ(5)" class="focus:outline-none p-5">
                    <span class="text-left md:text-center">What if I am not satisfied with the work and want a
                        refund?</span>
                    <span id="icon-5">+</span>
                </button>
                <div id="faq-5" class="faq-answer">
                    Although, we try our level best to satisfy our client and fulfill all of their requests but if they
                    still aren't satisfied till the very last, then we give a refund based on the project progress.
                </div>
            </div>
        </div>
    </section>

    <section
        class="pb-[150px] pt-[100px] flex items-center bg-[url(/assets/images/footer-form-bg.webp)] bg-right-bottom bg-cover bg-no-repeat text-white">
        <div class="grid md:grid-cols-2 gap-14 items-center md:w-[75%] w-[90%] mx-auto">
            <div>
                <h1 class="text-3xl font-semibold">How it Works?</h1>
                <ul class="mt-8 space-y-4">
                    <li class="flex gap-4">
                        <div class="!whitespace-nowrap">
                            <span
                                class="flex items-center rounded-full justify-center !h-[36px] !w-[36px] bg-[#4B4742]">1</span>
                        </div>
                        <p class="text-[14px]">
                            We understand that you may be unsure about how to begin the process and what steps to take
                            next. However, the procedure is straightforward since our 24-hour customer support team will
                            call you and collaborate with you within the following 24 hours.
                        </p>
                    </li>
                    <li class="flex gap-4">
                        <div class="!whitespace-nowrap">
                            <span
                                class="flex items-center rounded-full justify-center !h-[36px] !w-[36px] bg-[#4B4742]">2</span>
                        </div>
                        <p class="text-[14px]">
                            After analysing your project, our project managers will discuss it with our specialist
                            authors, and we will discuss the tone of your project with you.
                        </p>
                    </li>
                    <li class="flex gap-4">
                        <div class="!whitespace-nowrap">
                            <span
                                class="flex items-center rounded-full justify-center !h-[36px] !w-[36px] bg-[#4B4742]">3</span>
                        </div>
                        <p class="text-[14px]">
                            We will work on your project scope and deliver it in a timely manner once you have agreed on
                            the fundamental elements and tone of the project.
                        </p>
                    </li>
                    <li class="flex gap-4">
                        <div class="!whitespace-nowrap">
                            <span
                                class="flex items-center rounded-full justify-center !h-[36px] !w-[36px] bg-[#4B4742]">4</span>
                        </div>
                        <p class="text-[14px]">
                            The next step will be your consent to begin writing the first chapter, and you will be in
                            continual communication with us.
                        </p>
                    </li>
                </ul>
                <div class="flex md:gap-20 gap-2 items-center mt-10">
                   
                    <button onclick="toggleModal()"
                        class="gradientBg text-white h-[50px] w-[170px] justify-center rounded-xl text-sm flex gap-1 items-center">
                        Get Started Today
                        <i class="fa fa-angle-right"></i>
                    </button>
                    
                    <div class="flex gap-2 items-center">
                        <div
                            class="flex justify-center items-center h-11 w-11 rounded-full border border-white !text-white rotate-90">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                        </div>
                        <div class="flex flex-col justify-between text-white">
                            <div class="text-lg">Call Us</div>
                            <a href="tel:+18337471898" class="text-sm">+1 (833) 747-1898</a>
                        </div>
                    </div>
                </div>
            </div>
           
           <form action="sendEmail.php" method="POST" class="px-6 pt-6 pb-[50px] bg-[#041318] gradientBorder rounded-xl relative">
    <h1 class="text-2xl font-light w-[80%]">
        Sign Up Now to <span class="text-[var(--theme)]">Get 50%</span> Discount
    </h1>
    <div class="mt-5 space-y-4">
        <div class="grid grid-cols-2 gap-4">
            <input name="name" type="text" placeholder="Full Name" required
                class="col-span-2 py-[13px] px-4 bg-white text-black rounded-[7px]">
            <input name="email" type="email" placeholder="Email Address" required
                class="py-[13px] px-4 bg-white text-black rounded-[7px] col-span-2">
            <input name="phone" input type="number" type="text" placeholder="Phone Number" required
                class="py-[13px] px-4 bg-white text-black rounded-[7px] col-span-2">
        </div>
        <div class="grid grid-cols-2 gap-4">
            <select name="service" required class="py-[13px] px-4 bg-white text-black rounded-[7px]">
                <option value="" disabled selected>Select your Service</option>
                <option value="ghostwriting-services">Ghostwriting Services</option>
                <option value="book-editing-services">Book Editing Services</option>
                <option value="book-cover-design-services">Book Cover Design Services</option>
                <option value="ebook-cover-design-services">Ebook Cover Design Services</option>
                <option value="book-publishing-services">Book Publishing Services</option>
                <option value="book-marketing-services">Book Marketing Services</option>
                <option value="ebook-writing-services">Ebook Writing Services</option>
                <option value="biography-writing-services">Biography Writing Services</option>
                <option value="memoir-writing-services">Memoir Writing Services</option>
                <option value="book-printing-services">Book Printing Services</option>
                <option value="video-book-services">Video Book Services</option>
                <option value="audio-book-services">Audio Book Services</option>
                <option value="author-website-services">Author Website Services</option>
                <option value="book-illustration-services">Book Illustration Services</option>
            </select>
            <select name="budget" required class="py-[13px] px-4 bg-white text-black rounded-[7px]">
                <option value="" disabled selected>Budget...</option>
                <option value="$500 - $1000">$500 - $1,000</option>
                <option value="$1,000 - $5,000">$1,000 - $5,000</option>
                <option value="$5,000 - $10,000">$5,000 - $10,000</option>
                <option value="Others">Others</option>
            </select>
        </div>
        <textarea name="brief" placeholder="Brief.." rows="3"
            class="w-full py-[13px] px-5 bg-white text-black rounded-[7px]"></textarea>
        <button type="submit" class="text-white gradientBg py-3 w-full rounded-lg">Sign Up</button>
    </div>
</form>

           
           
        </div>
    </section>

    <footer>
        <div class="w-[90%] md:w-[84%] mx-auto py-12">
            <div class="mt-14 grid md:grid-cols-10 gap-4">
                <div class="grid md:grid-cols-3 md:col-span-7 md:gap-0 gap-8">
                    <div class="md:col-span-2">
                        <h1 class="text-[var(--theme2)] text-2xl font-semibold">Services</h1>
                        <ul class="mt-3 space-y-2 text-[14px] grid grid-cols-2 grid-rows-7 md:gap-x-0 gap-x-5">
                            <a href="./professional-ghostwriting-services" class="mt-2">Ghostwriting</a>
                    
                            <a href="./book-editing-services">Book Editing</a>
                            <a href="./book-cover-design">Book Cover Design</a>
                            <a href="./ebook-cover-design">Ebook Cover Design</a>
                            <a href="https://manorbookpublishers.com/book-writing">Book Writing</a>
                            <a href="./book-marketing">Book Marketing</a>
                            <a href="./ebook-writing-services">Ebook Writing Services</a>
                            <a href="./biography-writing">Biography Writing</a>
                            <a href="./memoir-writing">Memoir Writing</a>
                            <a href="./book-printing">Book Printing</a>
                            <a href="./audiobook-publishing-services">Audio Book</a>
                            <a href="./author-website-design">Author Website</a>
                            <a href="./book-illustration-services">Book Illustration</a>
                        </ul>
                    </div>
                    <div class="space-y-4">
                        <div>
                            <h1 class="text-[var(--theme2)] text-2xl font-semibold">Company</h1>
                            <ul class="mt-3 space-y-2 text-[14px]">
                                <li><a href="./about-us">About Us</a></li>
                                <li><a href="./contact-us">Contact Us</a></li>
                            </ul>
                        </div>
                        <div>
                            <h1 class="text-[var(--theme2)] text-2xl font-semibold">Policies</h1>
                            <ul class="mt-3 space-y-2 text-[14px]">
                                <li><a href='./privacy-policy'>Privacy Policy</a></li>
                        
                                <li><a href='./terms-condition'>Terms & Condition</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="md:col-span-3 md:mt-0 mt-5">
                    <h1 class="text-[var(--theme2)] text-2xl font-semibold">Contact Information</h1>
                    <ul class="mt-5 space-y-3 text-[15px]">
                        <a href="tel:+18337471898" class="flex gap-4 items-center">
                            <img loading="lazy" src="/assets/images/phone-icon-f.png" alt="Phone Icon">
                            +1(833)747-1898 
                        </a>
                        <!--  <a href="tel:+18335710235" class="flex gap-4 items-center">-->
                        <!--    <img loading="lazy" src="/assets/images/phone-icon-f.png" alt="Phone Icon">-->
                        <!--    +1(833)571-0235-->
                        <!--</a>-->
                        
                        <a href="mailto:info@manorbookpublishers.com" class="flex gap-4 items-center">
                            <img loading="lazy" src="/assets/images/email-icon-f.png" alt="Email Icon">
                            info@manorbookpublishers.com
                        </a>
                        <li class="flex gap-4 items-center">
                            <img loading="lazy" src="/assets/images/address-icon-f.png" alt="Address Icon">
                            New York Office 1: 70 E 55th St, New York, NY 10022
                        </li>
                        <li class="flex gap-4 items-center">
                            <img loading="lazy" src="/assets/images/address-icon-f.png" alt="Address Icon">
                            New York Office 2: 350 W 42nd St, New York, NY 10036
                        </li>
                        <!--  <li class="flex gap-4 items-center">
                            <img loading="lazy" src="/assets/images/address-icon-f.png" alt="Address Icon">
                            Branch Office: 13209 Kirkglen Dr Austin, Tx 78727, USA
                        </li> -->
                    </ul>
                    <img loading="lazy" src="/assets/images/customer-review.png" alt="Review Platforms" class="mt-7">
                </div>
            </div>
        </div>
        <div class="md:mt-9 bg-[#3DBEC1] py-8">
            <div class="grid md:grid-cols-2 md:gap-0 gap-11 text-white w-[90%] md:w-[84%] mx-auto text-[14px]">
                <p>All Rights Reserved 2026 - Manorbookpublishers</p>
                <img loading="lazy" src="/assets/images/cards.png" alt="Cards" class="md:ml-auto">
            </div>
        </div>
    </footer>
    
    <!--the popup form-->
    
    <div id="staticBackdrop1" class="hidden fixed inset-0 z-[9999] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
    
    <div class="relative bg-[#041318] w-full md:w-[500px] rounded-xl gradientBorder overflow-hidden shadow-2xl">
        
        <button onclick="toggleModal()" class="absolute top-4 right-4 text-gray-400 hover:text-white text-2xl z-10">&times;</button>
        
        <div class="p-6 md:p-8">
            <h3 class="text-white text-2xl mb-6 font-light">Avail Amazing <span class="text-[var(--theme)]">50% Discount Now!</span></h3>
            
            <form action="sendEmail.php" method="POST" id="popupForm" class="space-y-4">
                <input type="hidden" value="Popup Form" name="msg">
                
                <input type="text" name="fullName" placeholder="Full Name" class="w-full py-3 px-4 rounded-lg bg-white text-black focus:outline-[var(--theme)]" required>
                
                <input type="email" name="email" placeholder="Email Address" class="w-full py-3 px-4 rounded-lg bg-white text-black focus:outline-[var(--theme)]" required>
                
                <select name="service" class="w-full py-3 px-4 rounded-lg bg-white text-black focus:outline-[var(--theme)]" required>
                    <option value="" disabled selected>Select your Service</option>
                    <option value="Ghostwriting Services">Ghostwriting Services</option>
                    <option value="Book Editing Services">Book Editing Services</option>
                    <option value="Book Publishing Services">Book Publishing Services</option>
                    <option value="Book Marketing Services">Book Marketing Services</option>
                </select>

                <input name="phone" id="phoneInput" type="tel" placeholder="Phone Number" class="w-full py-3 px-4 rounded-lg bg-white text-black focus:outline-[var(--theme)]" required>

                <textarea name="brief" placeholder="Brief.." class="w-full py-3 px-4 rounded-lg bg-white text-black h-24 focus:outline-[var(--theme)]" required></textarea>
                
                <button type="submit" class="text-white gradientBg py-3 w-full rounded-lg font-bold uppercase hover:opacity-90 transition-all">Sign Up</button>
            </form>
        </div>
    </div>
</div>
    
    <!--the popupform end-->
    
    <!--thepopupform js-->
    
    <script>
// 1. Toggle function for your Popup
function toggleModal() {
    const modal = document.getElementById('staticBackdrop1');
    if(modal) modal.classList.toggle('hidden');
}

// 2. Global Validation
document.addEventListener('submit', function (e) {
    // Looks for phone, Number, or tel fields
    const phoneInput = e.target.querySelector('input[name="phone"], input[name="Number"], input[type="tel"]');
    
    if (phoneInput) {
        const phoneValue = phoneInput.value.replace(/\D/g, ''); // Strip non-digits
        
        // Remove any existing error message first
        const existingError = e.target.querySelector('.phone-error');
        if (existingError) existingError.remove();

        // CHANGE: Now only blocks if LESS than 10. (11, 12, etc. are now allowed)
        if (phoneValue.length < 10) {
            e.preventDefault(); // STOP submission
            
            const errorMsg = document.createElement('p');
            errorMsg.className = 'phone-error text-red-500 text-[11px] mt-1 ml-1 font-bold';
            errorMsg.innerText = 'Please enter at least 10 digits.';
            
            phoneInput.parentNode.insertBefore(errorMsg, phoneInput.nextSibling);
            phoneInput.style.border = "1px solid red";
            phoneInput.focus();
        }
    }
});

// 3. Clean up as user types
document.addEventListener('input', function (e) {
    const isPhoneField = e.target.name === 'phone' || e.target.name === 'Number' || e.target.type === 'tel';
    
    if (isPhoneField) {
        // Only allow numbers to be typed
        e.target.value = e.target.value.replace(/\D/g, '');
        
        // Remove error message and red border once they start typing
        const error = e.target.form?.querySelector('.phone-error');
        if (error) {
            error.remove();
            e.target.style.border = "";
        }
    }
});

// Close modal if clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('staticBackdrop1');
    if (event.target == modal) { modal.classList.add('hidden'); }
}
</script>
    
    <!--thepopupform js ends-->
    
   

    <script src="https://unpkg.com/swiper@9/swiper-bundle.min.js" defer></script>
    <script src="assets/js/swiper.js" defer></script>

    <script src="assets/js/index.js" defer></script>
</body>

</html>